# JenkinsPythonSDK

# Jenkins Python SDK (py_jenkins)

This SDK was developed because the other Jenkins SDKs are trash.
# Supported for python 3.8+
May work with older versions
# Note: Still being developed!

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install py-sjps.

```bash
pip install jenkins_pysdk
```

## Usage

```python
import py_jenkins as jenkins

# returns 'words'
sjps.<function>('word')

# returns 'geese'
sjps.<function>('goose')

# returns 'phenomenon'
sjps.<function>'phenomena')
```

## Contributing

Feel free to create pull requests.

For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)

This code is free to use and I will not take ANY responibilty for any damage that you create yourself.

## Contributors
AL

