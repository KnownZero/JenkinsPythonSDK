__all__ = ["Plugins"]


class Plugins:
    def __init__(self):
        pass

    @property
    def updates(self):
        raise NotImplemented

